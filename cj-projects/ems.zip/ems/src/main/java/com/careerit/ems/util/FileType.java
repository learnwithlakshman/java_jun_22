package com.careerit.ems.util;

public enum FileType {
	PDF,XLSX
}
